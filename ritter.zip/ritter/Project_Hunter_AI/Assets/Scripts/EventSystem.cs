using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventSystem : MonoBehaviour
{
    [SerializeField] Hunter hunter;
    private GameObject[] hunts;

    private Movement movement;

    public bool executing;
    public float stepDelay;
    private void Awake()
    {
        movement = GameObject.FindGameObjectWithTag("Movement").GetComponent<Movement>();

        executing = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        hunts = GameObject.FindGameObjectsWithTag("Hunt");

        StartCoroutine(simulation());
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            executeSimulation();

        else if (Input.GetKeyDown(KeyCode.H))
        {
            executing = !executing;
        }
    }

    void executeSimulation()
    {
        /*
         * checkHuntInRange()
         * detectCollision()
         * callMoveEntity()
         * 
         */

        detectCollision();
        callMoveEntity();
    }

    void callMoveEntity()
    {
        foreach (GameObject hunt in hunts)
        {
            hunt.transform.position = movement.moveEntityRandomly("hunt", hunt.transform.position);
        }

        //hunter.transform.position = movement.moveEntityRandomly("hunter", hunter.transform.position);
        hunter.transform.position = movement.moveHunter(hunter.transform.position);

    }

    void detectCollision()
    {
        int hunterPosX = Mathf.RoundToInt(hunter.transform.position.x);
        int hunterPosY = Mathf.RoundToInt(hunter.transform.position.y);

        //Debug.Log("#############################");

        for (int x = hunterPosX - 1; x <= hunterPosX + 1; x++)
        {
            for(int y = hunterPosY - 1; y <= hunterPosY + 1; y++)
            {
                //Debug.Log("(" + ((hunterPosX+x)- hunterPosX) + ", " + ((hunterPosY+y)- hunterPosY) + ")");

                foreach (GameObject hunt in hunts)
                {
                    if (hunt.transform.position == new Vector3(x, y, 0))
                    {
                        hunt.GetComponent<SpriteRenderer>().color = new Color(1, 0, 1, 1);
                        //hunt.SetActive(false);
                    }
                }
            }
        }
    }

    public IEnumerator simulation()
    {
        WaitForSeconds waitTime = new WaitForSeconds(stepDelay);

        while (true)
        {
            if (executing)
                executeSimulation();

            yield return waitTime;
        }
    }
}
