using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    //private Vector3 originalPosition;
    private Vector3 targetPosition;

    private List<Vector3> directions;

    public Hunter hunter;
    public GameObject[] hunts;

    private void Awake()
    {
        directions = new List<Vector3> { Vector3.up, Vector3.down, Vector3.left, Vector3.right };
    }

    // Start is called before the first frame update
    void Start()
    {
        hunts = GameObject.FindGameObjectsWithTag("Hunt");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Vector3 moveEntityRandomly(string entityType, Vector3 originalPosition)
    {
        //Debug.Log("moveEntRand()");

        Vector3 tempTargetPosition;
        int randomIndex;

        do
        {
            randomIndex = Random.Range(0, 4);

            tempTargetPosition = moveEntity(entityType, originalPosition, directions[randomIndex]);
        }
        while (tempTargetPosition.x < 0 || tempTargetPosition.x > 29 || tempTargetPosition.y < 0 || tempTargetPosition.y > 29);

        return tempTargetPosition;
    }

    public Vector3 moveHunter(Vector3 originalPosition)
    {
        float minDistance = 9999;
        Vector3 tempDirection = directions[Random.Range(0,4)];

        foreach (GameObject hunt in hunts)
        {
            if (hunt.GetComponent<Hunt>().isBeingHunted)
            {
                for (int i = 0; i < 4; i++)
                {
                    if (i == 0)
                    {
                        //minDistance = hunter.transform.position + directions[i] - hunt.transform.position;
                        minDistance = Vector3.Distance(hunter.transform.position + directions[i], hunt.transform.position);
                        tempDirection = directions[i];
                    }
                    else
                    {
                        Vector3 tempv3 = hunter.transform.position + directions[i] - hunt.transform.position;

                        if (Vector3.Distance(hunter.transform.position + directions[i], hunt.transform.position) < minDistance)
                        {
                            tempDirection = directions[i];
                        }
                    }
                }
            }
        }

        return originalPosition + tempDirection;
    }

    public Vector3 moveEntity(string entityType, Vector3 originalPosition, Vector3 direction)
    {
        if (entityType.Equals("Hunter"))
        {
            /*
            for(int i = 0; i < 4; i++)
            {
                Vector3 minDistance;

                if (i == 0)
                {
                    minDistance = directions[i];
                }

                foreach(GameObject hunt in hunts)
                {
                    if (hunt.GetComponent<Hunt>().isBeingHunted)
                    {

                    }
                }
            }
            */

            float minDistance = 9999;
            Vector3 tempDirection;

            foreach (GameObject hunt in hunts)
            {
                if (hunt.GetComponent<Hunt>().isBeingHunted)
                {
                    for(int i = 0; i < 4; i++)
                    {
                        if (i == 0)
                        {
                            //minDistance = hunter.transform.position + directions[i] - hunt.transform.position;
                            minDistance = Vector3.Distance(hunter.transform.position + directions[i], hunt.transform.position);
                            tempDirection = directions[i];
                        }
                        else
                        {
                            Vector3 tempv3 = hunter.transform.position + directions[i] - hunt.transform.position;

                            if (Vector3.Distance(hunter.transform.position + directions[i], hunt.transform.position) < minDistance)
                            {
                                tempDirection = directions[i];
                            }
                        }
                    }
                }
            }


        }
        else
        {

        }

        targetPosition = originalPosition + direction;

        return targetPosition;


    }
}
